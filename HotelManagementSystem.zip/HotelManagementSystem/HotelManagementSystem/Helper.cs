﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using HotelManagementSystem.Models;

namespace HotelManagementSystem
{
    public class Helper
    {
        private HotelManagement_PR_21_101_PervushinEntities _context;

        public Helper()
        {
            _context = new HotelManagement_PR_21_101_PervushinEntities();
        }

        // Чтение данных гостей
        public List<Guests> GetGuests()
        {
            return _context.Guests.ToList();
        }

        // Получение всех комнат
        public List<Rooms> GetRooms()
        {
            return _context.Rooms.ToList();
        }

        // Добавление нового гостя
        public void AddGuest(Guests guest)
        {
            if (guest != null)
            {
                _context.Guests.Add(guest);
                _context.SaveChanges();
            }
        }

        // Редактирование информации о госте
        public void UpdateGuest(Guests guest)
        {
            if (guest != null)
            {
                _context.Entry(guest).State = EntityState.Modified;
                _context.SaveChanges();
            }
        }

        // Удаление гостя
        public void DeleteGuest(int guestId)
        {
            var guest = _context.Guests.Find(guestId);
            if (guest != null)
            {
                _context.Guests.Remove(guest);
                _context.SaveChanges();
            }
        }

        // Получение забронированных комнат
        public List<Reservations> GetReservations()
        {
            return _context.Reservations.Include(r => r.Guests).Include(r => r.Rooms).ToList();
        }
    }
}
