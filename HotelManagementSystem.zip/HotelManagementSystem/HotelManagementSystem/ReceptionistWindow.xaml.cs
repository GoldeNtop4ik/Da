﻿using HotelManagementSystem.Models;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace HotelManagementSystem
{
    public partial class ReceptionistWindow : Window
    {
        private readonly HotelManagement_PR_21_101_PervushinEntities _context;
        private readonly Staff _currentUser;

        public ReceptionistWindow(Staff user)
        {
            InitializeComponent();
            _context = new HotelManagement_PR_21_101_PervushinEntities();
            _currentUser = user;
            LoadRooms();
            DisplayUserInfo();
        }

        private void LoadRooms()
        {
            var rooms = _context.Rooms.Include("RoomTypes").ToList();
            RoomsListBox.ItemsSource = rooms;
            NoResultsTextBlock.Visibility = rooms.Any() ? Visibility.Collapsed : Visibility.Visible;
        }

        private void DisplayUserInfo()
        {
            UserNameTextBlock.Text = $"{_currentUser.LastName} {_currentUser.FirstName}";
            GreetingTextBlock.Text = GetGreeting();
        }

        private string GetGreeting()
        {
            var now = DateTime.Now.TimeOfDay;
            if (now >= new TimeSpan(6, 0, 0) && now < new TimeSpan(12, 0, 0))
            {
                return "Доброе утро";
            }
            else if (now >= new TimeSpan(12, 0, 0) && now < new TimeSpan(18, 0, 0))
            {
                return "Добрый день";
            }
            else if (now >= new TimeSpan(18, 0, 0) && now < new TimeSpan(21, 0, 0))
            {
                return "Добрый вечер";
            }
            return "Доброй ночи";
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var searchQuery = SearchTextBox.Text.ToLower();
            var filteredRooms = _context.Rooms.Include("RoomTypes")
                .Where(r => r.RoomNumber.ToString().Contains(searchQuery) ||
                            r.RoomTypes.Name.ToLower().Contains(searchQuery) ||
                            r.Price.ToString().Contains(searchQuery))
                .ToList();

            RoomsListBox.ItemsSource = filteredRooms;
            NoResultsTextBlock.Visibility = filteredRooms.Any() ? Visibility.Collapsed : Visibility.Visible;
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedSort = (SortComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            var rooms = _context.Rooms.Include("RoomTypes").ToList();

            switch (selectedSort)
            {
                case "Имя комнаты":
                    rooms = rooms.OrderBy(r => r.RoomNumber).ToList();
                    break;
                case "Тип комнаты":
                    rooms = rooms.OrderBy(r => r.RoomTypes.Name).ToList();
                    break;
                case "Цена":
                    rooms = rooms.OrderBy(r => r.Price).ToList();
                    break;
            }

            RoomsListBox.ItemsSource = rooms;
            NoResultsTextBlock.Visibility = rooms.Any() ? Visibility.Collapsed : Visibility.Visible;
        }

        private void RegisterGuestButton_Click(object sender, RoutedEventArgs e)
        {
            var registrationWindow = new GuestRegistrationWindow();
            registrationWindow.ShowDialog();
            LoadRooms();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            // Переход на окно авторизации
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }
    }
}
