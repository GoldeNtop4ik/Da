﻿using HotelManagementSystem.Models;
using System;
using System.Windows;

namespace HotelManagementSystem
{
    public partial class ManagerWindow : Window
    {
        private readonly Staff _currentUser;

        public ManagerWindow(Staff user)
        {
            InitializeComponent();
            _currentUser = user;
            DisplayUserInfo();
        }

        private void DisplayUserInfo()
        {
            UserNameTextBlock.Text = $"{_currentUser.LastName} {_currentUser.FirstName}";
            GreetingTextBlock.Text = GetGreeting();
        }

        private string GetGreeting()
        {
            var now = DateTime.Now.TimeOfDay;
            if (now >= new TimeSpan(6, 0, 0) && now < new TimeSpan(12, 0, 0))
            {
                return "Доброе утро";
            }
            else if (now >= new TimeSpan(12, 0, 0) && now < new TimeSpan(18, 0, 0))
            {
                return "Добрый день";
            }
            else if (now >= new TimeSpan(18, 0, 0) && now < new TimeSpan(21, 0, 0))
            {
                return "Добрый вечер";
            }
            return "Доброй ночи";
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }
    }
}
