﻿using HotelManagementSystem.Models;
using System;
using System.Linq;
using System.Windows;

namespace HotelManagementSystem
{
    public partial class GuestRegistrationWindow : Window
    {
        private readonly HotelManagement_PR_21_101_PervushinEntities _context;

        public GuestRegistrationWindow()
        {
            InitializeComponent();
            _context = new HotelManagement_PR_21_101_PervushinEntities();
            LoadAvailableRooms(); // Загрузка списка доступных комнат
        }

        private void LoadAvailableRooms()
        {
            // Загрузка комнат, доступных для бронирования
            var availableRooms = _context.Rooms.Where(r => r.Availability == true).ToList();
            RoomComboBox.ItemsSource = availableRooms;
            RoomComboBox.DisplayMemberPath = "RoomNumber"; // Отображение номера комнаты
            RoomComboBox.SelectedValuePath = "ID"; // Идентификатор комнаты
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создание объекта гостя и заполнение полей
                var guest = new Guests
                {
                    FirstName = FirstNameTextBox.Text,
                    LastName = LastNameTextBox.Text,
                    Email = string.IsNullOrEmpty(EmailTextBox.Text) ? null : EmailTextBox.Text,
                    PhoneNumber = PhoneNumberTextBox.Text,
                    DateOfBirth = DateOfBirthPicker.SelectedDate ?? DateTime.Now
                };

                _context.Guests.Add(guest);
                _context.SaveChanges(); // Сохранение гостя в базе данных

                int roomId = (int)RoomComboBox.SelectedValue;
                int stayDuration = int.Parse(StayDurationTextBox.Text);

                // Создание объекта бронирования
                var reservation = new Reservations
                {
                    GuestID = guest.ID,
                    RoomID = roomId,
                    CheckInDate = DateTime.Today,
                    CheckOutDate = DateTime.Today.AddDays(stayDuration),
                    StatusID = _context.Statuses.First(s => s.Name == "Booked").ID
                };

                // Обновление статуса комнаты на недоступную
                var room = _context.Rooms.Find(roomId);
                room.Availability = false;

                _context.Reservations.Add(reservation);
                _context.SaveChanges(); // Сохранение бронирования в базе данных

                MessageBox.Show("Гость успешно зарегистрирован.", "Регистрация", MessageBoxButton.OK, MessageBoxImage.Information);
                Close(); // Закрытие окна после успешной регистрации
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при регистрации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
