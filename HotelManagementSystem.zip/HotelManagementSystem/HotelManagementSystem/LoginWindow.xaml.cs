﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using HotelManagementSystem.Models;

namespace HotelManagementSystem
{
    public partial class LoginWindow : Window
    {
        private bool isPasswordVisible = false;
        private string generatedCaptcha;
        private int failedAttempts = 0;

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string username = UsernameTextBox.Text;
                string password = isPasswordVisible ? PasswordTextBox.Text : PasswordBox.Password;

                if (CaptchaPanel.Visibility == Visibility.Visible && CaptchaInputTextBox.Text != generatedCaptcha)
                {
                    MessageBox.Show("Неверная CAPTCHA.");
                    failedAttempts++;
                    HandleFailedAttempt();
                    return;
                }

                using (var context = new HotelManagement_PR_21_101_PervushinEntities())
                {
                    var user = context.Staff.FirstOrDefault(u => u.Username == username && u.Password == password);
                    if (user != null)
                    {
                        Window nextWindow;
                        switch (user.PositionID)
                        {
                            case 1: // Менеджер
                                nextWindow = new ManagerWindow(user);
                                break;
                            case 2: // Ресепшионист
                                nextWindow = new ReceptionistWindow(user);
                                break;
                            default:
                                MessageBox.Show("Неизвестная роль пользователя.");
                                return;
                        }

                        nextWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверное имя пользователя или пароль.");
                        failedAttempts++;
                        HandleFailedAttempt();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }
        }

        private void HandleFailedAttempt()
        {
            if (failedAttempts >= 1)
            {
                if (failedAttempts == 1)
                {
                    CaptchaPanel.Visibility = Visibility.Visible;
                    GenerateCaptcha();
                }
                else if (failedAttempts > 1)
                {
                    MessageBox.Show("Вход заблокирован на 10 секунд.");
                    LoginButton.IsEnabled = false;
                    Task.Delay(TimeSpan.FromSeconds(10)).ContinueWith(_ =>
                    {
                        Dispatcher.Invoke(() => LoginButton.IsEnabled = true);
                    });
                }
            }
        }

        private void GenerateCaptcha()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            var captchaBuilder = new StringBuilder(6);
            for (int i = 0; i < 6; i++)
            {
                captchaBuilder.Append(chars[random.Next(chars.Length)]);
            }
            generatedCaptcha = captchaBuilder.ToString();
            CaptchaTextBlock.Text = generatedCaptcha;
        }

        private void ShowPassword_Click(object sender, RoutedEventArgs e)
        {
            isPasswordVisible = !isPasswordVisible;
            if (isPasswordVisible)
            {
                PasswordTextBox.Text = PasswordBox.Password;
                PasswordBox.Visibility = Visibility.Collapsed;
                PasswordTextBox.Visibility = Visibility.Visible;
                (sender as Button).Content = "Скрыть";
            }
            else
            {
                PasswordBox.Password = PasswordTextBox.Text;
                PasswordBox.Visibility = Visibility.Visible;
                PasswordTextBox.Visibility = Visibility.Collapsed;
                (sender as Button).Content = "Показать";
            }
        }
    }
}
